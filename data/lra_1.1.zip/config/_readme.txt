This folder contains configuration files for LRA (LFS Replay Analyser). They
contain info on cars and tracks, which LRA uses to recognise the data in the
RAF files.

You don't need to install these files: lra.exe contains a copy of this data, so
LRA can work without them. But if new cars or tracks are added to LFS in the
future, you can edit these files yourself. An update of LRA itself is not
required.

The syntax of each file is explained inside the files. Comments are preceded by a "#".
