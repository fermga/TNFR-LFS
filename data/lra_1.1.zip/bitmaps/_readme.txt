This folder contains bitmap files for LRA (LFS Replay Analyser). They
contain images of the tracks, to be shown in the Driving Line pane.

LRA is distributed without any of these files. They can be downloaded
from the main LFS site, at http://www.lfs.net/file_lfs.php?name=TRACKS_TIF.zip
To install them, you should extract the ZIP file and place the TIF files in this folder.