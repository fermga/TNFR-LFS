HOW TO MAKE A NEW TRANSLATION FOR LFS REPLAY ANALYSER
-----------------------------------------------------

Language files for LRA are stored in the subfolder "language". If this doesn't exist yet, create it
and copy file "English.txt" from your LRA distribution into it. Now copy this file and give it the
name of your new language (but keep the extension ".txt").

In the file, you will find the text strings that LRA uses. Each string has a 4-digit numeric
identifier, followed by either a "t" for the text itself, or an "h" for the associated help text.
(NB: The help text currently only works for items on the menu bar. The help will be shown in the
status bar, as is normal for Windows applications.)

LRA reads the available language files when it starts up. When you have made some changes in the
file and want to make LRA re-load it, select the name in the "Language" submenu.


SPECIAL CHARACTERS
------------------

- An ampersand ("&") before a character marks the accelerator key (= the underlined letter). This
only works for menu items and for buttons.

- A hash ("#") indicates a comment. This character and the rest of the line after it are ignored.

- A tab character separates the text of a menu item from its hotkey. You can change the hotkey to
your liking. If you want to know how to set the hotkey, read the documentation at
http://www.wxwidgets.org/manuals/stable/wx_wxmenu.html#wxmenuappend
